# Precision Pools — security review scope

**Ethereum mainnet. Live, unpaused, holding real value.**

---

## What we are asking for

These contracts are deployed and have been handling real value. We are not
looking for a catalogue of theoretical findings against a hypothetical
configuration — we are asking a narrower and harder question:

> **Under the deployment configuration recorded below, is this system safe to
> keep running, and safe to keep launching tokens into?**

Concretely, what is useful to us:

- **A go / no-go.** State plainly whether you believe the deployed system is
  sound as configured, or that it is not, and why.
- **Exploitability under the real configuration**, not an imagined one. The
  immutable wiring is fixed at the values in §4. A finding that requires a
  different `trustedExecutor`, a different factory, or an owner we do not
  control is not a finding about this deployment — say so, and rank it
  accordingly.
- **Severity that means something.** If it cannot lose or freeze user funds,
  mint or inflate supply, or brick a pool, please rank it Informational and move
  on. We would rather receive six real issues than sixty we have to triage.
- **Where you looked and found nothing.** Negative results are valuable. An
  explicit "I modelled reentrancy across route → pool → token callbacks and the
  transient guards hold" is worth more to us than silence on the topic.

What we do **not** need: gas golf, style, naming, NatSpec completeness, or
`unchecked` audits where overflow is unreachable. The code is deliberately terse
and heavily commented — please read the comments, as several document decisions
that look like bugs at first glance.

---

## 1. Scope

### Core — custody and accounting. This is the engagement.

| Contract | SLOC | Role |
| --- | --- | --- |
| `src/pools/PrecisionPool.sol` | 763 | The AMM. Holds all pool liquidity. |
| `src/pools/PrecisionPoolFactory.sol` | 413 | Deploys pools; CREATE2 + SSTORE2 pool code. |
| `src/pools/PrecisionRoute.sol` | 341 | Multi-hop routing **and** `zapIn`. Takes custody mid-transaction. |
| `src/pools/PrecisionLauncher.sol` | 327 | Token launch: mints the coin, seeds the pool. |
| ├─ `LaunchToken` *(same file, L26–329)* | 84 | The ERC-20 every launched coin is a clone of. |
| └─ `PrecisionLauncher` *(same file, L330+)* | 231 | The launcher proper. |
| `src/pools/PriceTape.sol` | 154 | `library`, linked into the pool. On-chain OHLCV ring buffer. |
| `src/pools/PrecisionPoolPolicy.sol` | 64 | Ownable policy consulted by the route. |
| **Total** | **≈2,062** | |

**Highest risk, in our own estimation:** `PrecisionPool` (it holds the money)
and `PrecisionRoute` (it holds the money *transiently*, and `zapIn` is the most
composed path in the system). `PrecisionLauncher` matters because a launch mints
supply and seeds a pool in one transaction — a mispriced or front-runnable seed
is a real loss even though the launcher holds nothing afterwards.

### Read-only lenses — secondary, but not ignorable

| Contract | SLOC | Note |
| --- | --- | --- |
| `src/pools/PrecisionPoolLens.sol` | 355 | |
| `src/pools/PrecisionLiquidityLens.sol` | 215 | `previewZap` sizes real zap transactions. |
| `src/pools/PrecisionLauncherLens.sol` | 108 | |

No custody. They matter because the dapp **prices and sizes user trades from
them** — a wrong answer becomes a bad trade behind a correct-looking UI. Worth a
pass for arithmetic that disagrees with the pool it describes, especially
`previewZap` versus `PrecisionRoute.zapIn`.

### Included, not deployed — decide with us

| Contract | SLOC | Note |
| --- | --- | --- |
| `src/pools/PrecisionZap.sol` | 130 | **Not separately deployed.** `zapIn` lives inside the deployed `PrecisionRoute`. Reference only — audit the Route. |
| `src/pools/ConstantSurchargeHook.sol` | 91 | No deployment. Review only if we say we intend to ship it. |
| `src/pools/FeeSplitter.sol` | 71 | No deployment. Same. |

### Explicitly OUT of scope

`PrecisionOraclePool.sol`, `PrecisionRangePool.sol`, `PrecisionStablePool.sol`
— all three carry `NOT FOR DEPLOYMENT` headers in-repo and are single-pair
references and gas baselines kept beside the generalised pool. ~581 SLOC.
**Please do not bill for these.** `src/zPool.sol` is a separate, older pool and
is not part of this system.

**The rest of `src/` is present so the repo builds and the tests run. It is not
in scope.** Only the tables above are.

---

## 2. Build

The bundle builds standalone from a bare unzip:

```
forge build      # verified: exit 0, no errors
```

```
solc           0.8.36
via_ir         true
optimizer      true, runs = 9_999_999
evm_version    prague
```

`evm_version` is pinned deliberately. **Cancun is a hard floor**:
`PrecisionPool`, `PrecisionRoute` and `PrecisionPoolFactory` all guard
reentrancy with `TSTORE`/`TLOAD`. A pre-Cancun target does not weaken the guards
— it fails to compile. Please treat transient-storage reentrancy as a
first-class area.

**Dependencies, pinned by submodule and vendored into `lib/`:**

| Library | Version | Commit |
| --- | --- | --- |
| `solady` | v0.1.26 | `acd959aa4bd04720d640bf4e6a5c71037510cc4b` |
| `forge-std` *(tests only)* | v1.15.0 | `0844d7e1fc5e60d77b68e469bff60265f236c398` |

Used from solady: `ERC20`, `Ownable`, `ReentrancyGuard`, `SafeTransferLib`,
`FixedPointMathLib`, `LibClone`, `SSTORE2`, `Base64`, `LibString`. `LibClone` is
load-bearing — the factory's determinism and the launcher's token cloning both
depend on it.

---

## 3. Deployed addresses, and source↔bytecode verification

Every contract below was verified by compiling this exact tree and comparing the
result against `eth_getCode` on mainnet.

| Contract | Address | Runtime | Verification |
| --- | --- | --- | --- |
| `PrecisionPoolFactory` | `0x000000Eb27B557aB426d9E99cFd54EC455799e81` | 7,898 B | ✅ identical outside immutables (9 slots) |
| `PrecisionPoolLens` | `0x000000Bad3a2fa57ed74fa06000573ccddF6B7fB` | 12,562 B | ✅ identical outside immutables (12 slots) |
| `PrecisionLiquidityLens` | `0x000000956bf20A41C54BaE4a4b6F5C8A166DAB4E` | 5,456 B | ✅ identical outside immutables (2 slots) |
| `PrecisionRoute` | `0x0000007Be74558A1F8c9045301c6F44C8eD0c9eB` | 7,264 B | ✅ identical outside immutables (12 slots) |
| `PrecisionPoolPolicy` | `0x00000045fc7b570Be4d71F67219508ebD295EC6D` | 2,185 B | ✅ identical outside immutables (3 slots) |
| `PrecisionLauncher` | `0x0000002fC8E77585A008Aa45d78A71ad36293aEe` | 9,138 B | ✅ identical outside immutables (11 slots) |

**Method.** Runtime lengths matched exactly. Every differing byte fell inside a
compiler-declared `immutableReferences` slot; masking those slots to zero made
local and on-chain runtime byte-identical. So the source in this bundle *is* the
code at these addresses, differing only in constructor-injected configuration —
which is enumerated in §4 rather than left implicit. Raw results in
`bytecode-verification.json`.

`PrecisionPool` is not a singleton: the factory deploys one per market via
CREATE2 from SSTORE2-stored creation code. A live instance to examine is zCat's
pool, `0xe9a1ff118d4def752f9d98814a7c4080030584e1` (19,440 B runtime).

---

## 4. Live immutable configuration

This is the configuration the system actually runs under. Findings requiring
different values here are not findings about this deployment.

**`PrecisionPoolFactory`** — `trustedExecutor`, `poolCode`, `poolInitCodeHash`
- `trustedExecutor` = `0x25fc36455aa30d012bbfb86f283975440d7ee8db` (252 B)
- `poolCode` = `0x7a1594343000034dbbdfa5ca3243edd8f88d7c00` (20,631 B — SSTORE2 blob holding pool creation code)
- `poolInitCodeHash` is a `bytes32`, not an address; read it from the contract rather than from a bytecode slice.

**`PrecisionRoute`** — `trustedExecutor`, `factory`
- `trustedExecutor` = `0x25fc36455aa30d012bbfb86f283975440d7ee8db` (same executor as the factory)
- `factory` = `0x000000Eb27B557aB426d9E99cFd54EC455799e81`

**`PrecisionLauncher`** — `factory`, `tokenImplementation`, `treasury`
- `factory` = `0x000000Eb27B557aB426d9E99cFd54EC455799e81`
- `tokenImplementation` = `0xc931ea35093de3cd045f69258f107cd567fe4759` (7,615 B — the `LaunchToken` every coin clones)
- `treasury` = `0x000000aa142133107c7d2664f900f80e28bbffbd` (3,227 B)

**`PrecisionPoolPolicy`**, **`PrecisionPoolLens`**, **`PrecisionLiquidityLens`**
- `factory` = `0x000000Eb27B557aB426d9E99cFd54EC455799e81`

The `trustedExecutor` is 252 bytes and shared between the factory and the route.
**Its trust boundary deserves explicit attention** — please tell us what an
attacker controlling it could do, and whether anything else ought to depend on
it.

---

## 5. Existing tests

65 Foundry test files (≈11,282 SLOC) touch the in-scope contracts, included
under `test/` along with the shared helpers they import. Coverage by contract,
as a map of where we have already looked:

| Contract | Test files |
| --- | --- |
| `PrecisionPool` | 60 |
| `PrecisionPoolFactory` | 57 |
| `PrecisionLauncher` | 18 |
| `LaunchToken` | 17 |
| `PrecisionRoute` | 11 |
| `PriceTape` | 8 |
| `PrecisionPoolPolicy` | 2 |

Several are named `Audit*.t.sol` and encode findings from earlier review rounds
— worth reading first, both for what was found and for what was deliberately
accepted. Some fork mainnet and need an **archive** RPC; set
`FOUNDRY_ETH_RPC_URL`.

`PrecisionPoolPolicy` at 2 test files is our thinnest coverage.

---

## 6. Context you should have

**These are live and have handled real value**, exposed on mainnet without
incident so far. We read that as encouraging, not as proof — which is why we are
commissioning this.

**But the deployed surface is lightly exercised.** As of this writing there are
**zero precision pools for every token on our curated list** — verified: the
lens is deployed and returns a well-formed empty result for ETH/USDC, wstETH,
rETH, WBTC, USDC, USDT, BOLD and the rest. The one substantial live pool is
zCat's, `0xe9a1ff118d4def752f9d98814a7c4080030584e1`. Please do not read
"survived mainnet" as "battle-tested at volume" — the honest position is that
this code has been exposed, not stressed.

**The launcher is about to get more traffic.** We are marketing token launches
on zSwap, so `PrecisionLauncher` + `LaunchToken` will see materially more use
than they have. Weight that path by where the volume is going, not where it has
been.

**Where we would spend your time, if it were ours:**

1. `PrecisionRoute.zapIn` — the most composed path: single-sided entry, custody
   held across an external call, `checkpoint` intent-hashing.
2. Transient-storage reentrancy guards across route → pool → token callbacks,
   including a malicious ERC-20 as one side of a pool.
3. Launch seeding — can the opening price be manipulated or sandwiched, or the
   seed front-run between mint and pool creation?
4. `PriceTape` — a library writing packed OHLCV into pool storage. A corruptible
   tape is not a fund loss, but it is what our charts price from.
5. The `trustedExecutor` trust boundary (§4).
6. Factory CREATE2 / SSTORE2 determinism — can a pool address be squatted, or a
   pool deployed with mismatched code?

---

## 7. Bundle contents

```
SCOPE.md                    this document
HASHES.txt                  sha256 of every in-scope source file
bytecode-verification.json  raw source↔deployed comparison (§3)
foundry.toml                exact build configuration
src/                        full source tree — only §1 is in scope
test/                       65 test files touching the in-scope set, + helpers
lib/solady/                 vendored at the pinned commit
lib/forge-std/              vendored at the pinned commit
```

Source tree: `1a2c74c5e1d456dd1c7e2e36a6904a769efe70f5`. The working tree also
carries uncommitted changes to the dapp front-end (`zSwap.html`), which is **not
in scope** and is not included here.

Verify the contracts you review against `HASHES.txt`.
